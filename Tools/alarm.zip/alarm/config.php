<?php

// list
$inputList = 'list.txt'; // list.txt

// telegram
$telegramToken = '1636156252:AAG9CNf9eQfw9iKX68fjCfsfh0D4maVWIuw'; // token telegram bot
$telegramChatId = '1192315757'; // chat id telegram